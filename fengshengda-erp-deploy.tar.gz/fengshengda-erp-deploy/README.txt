# 丰晟达 ERP（鸡爪供应链）部署包

> 版本：v0.6 | 构建日期：2026-06-23 | 文件数：127 | 大小：~2.5MB

## 快速开始

```bash
# 1. 解压
tar xzf fengshengda-erp-deploy.tar.gz
cd fengshengda-erp-deploy

# 2. 一键安装（需要 root）
chmod +x setup.sh
sudo bash setup.sh

# 3. 访问
# 前端：https://your-domain.com
# 默认账号：boss / demo
```

## 部署包内容

```
fengshengda-erp-deploy/
├── setup.sh                  # 一键安装脚本
├── DEPLOY.md                 # 完整部署文档
├── package.json              # npm 依赖声明
├── package-lock.json         # npm 锁定版本
├── ecosystem.config.cjs      # pm2 进程配置
├── .env.production.example   # 环境变量模板
├── server/                   # NestJS 后端源码
│   └── src/                  # TypeScript 源码
├── frontend/
│   ├── dist/                 # ★ 已构建好的前端静态文件
│   ├── src/                  # React 源码（可选重构建）
│   ├── index.html
│   └── vite.config.ts
├── nginx/
│   └── erp.example.com.conf  # nginx HTTPS 配置模板
└── scripts/                  # 运维脚本
```

## 前提条件

| 组件 | 要求 |
|------|------|
| Ubuntu | 20.04+ / Debian 11+ |
| Node.js | v22.x |
| MySQL | 8.0+ / MariaDB 10.11+ |
| nginx | 1.18+ |

## 手动部署

详见 `DEPLOY.md`，共 14 章节，涵盖：
- 环境初始化
- MySQL 建库建用户
- nginx HTTPS 配置
- pm2 进程守护
- 备份策略
- 日常运维

## 默认账号

| 用户名 | 密码 | 角色 |
|--------|------|------|
| boss | demo | 老板（全部权限） |
| finance | demo | 财务 |
| warehouse | demo | 仓储 |
| sales01 | demo | 销售 |

## 技术栈

- **后端**：NestJS 10 + TypeORM + MySQL 8 + JWT + Swagger
- **前端**：Vite 5 + React 18 + Ant Design 5 + Zustand
- **进程**：pm2 (systemd 开机自启)
- **代理**：nginx (HTTPS 终止 + SPA fallback + API 反代)

## 端口

| 端口 | 用途 | 对外 |
|------|------|------|
| 80/443 | nginx HTTP/HTTPS | ✅ |
| 3003 | NestJS 后端 | ❌ (仅本机) |
| 3306 | MySQL | ❌ (仅本机) |
