#!/bin/bash
# ============================================================
# 丰晟达 ERP（鸡爪供应链）部署包安装脚本
# ============================================================
# 用法：chmod +x setup.sh && sudo bash setup.sh
# 前提：Node 22 + MySQL 8 + nginx 已安装
# ============================================================
set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  丰晟达 ERP · 鸡爪供应链 一键部署${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""

# ====== 配置区（按需修改）======
INSTALL_DIR=${INSTALL_DIR:-/data/erp-system}
DOMAIN=${DOMAIN:-erp.example.com}
DB_PASS=${DB_PASS:-}     # 留空则自动生成
JWT_SECRET=${JWT_SECRET:-} # 留空则自动生成
NODE_ENV=production

# ====== 1. 检查环境 ======
echo -e "${YELLOW}[1/7] 检查环境...${NC}"

if ! command -v node &>/dev/null; then
    echo -e "${RED}❌ 未安装 Node.js。请先运行：nvm install 22${NC}"
    exit 1
fi
echo "  Node.js: $(node --version)"

if ! command -v pm2 &>/dev/null; then
    echo -e "${YELLOW}  pm2 未安装，正在安装...${NC}"
    npm install -g pm2
fi
echo "  pm2: $(pm2 --version)"

if ! command -v nginx &>/dev/null; then
    echo -e "${YELLOW}  nginx 未安装，正在安装...${NC}"
    apt-get update && apt-get install -y nginx
fi
echo "  nginx: $(nginx -v 2>&1)"

# ====== 2. 创建目录 ======
echo -e "${YELLOW}[2/7] 创建安装目录...${NC}"
mkdir -p $INSTALL_DIR
cp -r ./* $INSTALL_DIR/
cp .env.production.example $INSTALL_DIR/server/.env 2>/dev/null || cp $INSTALL_DIR/.env.production.example $INSTALL_DIR/server/.env

# ====== 3. 生成密钥 ======
echo -e "${YELLOW}[3/7] 生成密钥...${NC}"
if [ -z "$DB_PASS" ]; then
    DB_PASS=$(openssl rand -hex 16)
    echo "  数据库密码已生成: ${DB_PASS:0:8}..."
fi
if [ -z "$JWT_SECRET" ]; then
    JWT_SECRET=$(openssl rand -hex 16)
    echo "  JWT 密钥已生成: ${JWT_SECRET:0:8}..."
fi

# ====== 4. 配置环境变量 ======
echo -e "${YELLOW}[4/7] 配置环境变量...${NC}"
cat > $INSTALL_DIR/server/.env << ENVEOF
# ====== 数据库 ======
DB_TYPE=mysql
DB_HOST=localhost
DB_PORT=3306
DB_USER=erp_user
DB_PASS=$DB_PASS
DB_NAME=fengshengda_erp

# ====== JWT ======
JWT_SECRET=$JWT_SECRET
JWT_EXPIRES_IN=24h

# ====== CORS 白名单 ======
CORS_ORIGINS=https://$DOMAIN,http://localhost:5173

# ====== 文件上传 ======
UPLOAD_DIR=./uploads
MAX_UPLOAD_MB=20

# ====== 限流 ======
THROTTLE_LIMIT=60

# ====== 日志 ======
LOG_LEVEL=info
NODE_ENV=$NODE_ENV
PORT=3003
ENVEOF
echo "  ✅ server/.env 已生成"

# ====== 5. 安装依赖 ======
echo -e "${YELLOW}[5/7] 安装 npm 依赖...${NC}"
cd $INSTALL_DIR
npm install --production --prefer-offline 2>&1 | tail -3
echo "  ✅ 依赖安装完成"

# ====== 6. 配置 nginx ======
echo -e "${YELLOW}[6/7] 配置 nginx...${NC}"
NGINX_CONF=/etc/nginx/sites-available/fengshengda-erp
if [ -f "$INSTALL_DIR/nginx/erp.example.com.conf" ]; then
    sed "s|erp.example.com|$DOMAIN|g; s|/data/erp-system|$INSTALL_DIR|g" \
        $INSTALL_DIR/nginx/erp.example.com.conf > $NGINX_CONF
    ln -sf $NGINX_CONF /etc/nginx/sites-enabled/
    nginx -t && systemctl reload nginx
    echo "  ✅ nginx 配置完成"
else
    echo "  ⚠️  未找到 nginx 模板，跳过"
fi

# ====== 7. 启动服务 ======
echo -e "${YELLOW}[7/7] 启动服务...${NC}"
cd $INSTALL_DIR

# 停止旧进程
pm2 delete fengshengda-server 2>/dev/null || true

# 启动后端
pm2 start ecosystem.config.cjs --only fengshengda-server --env production
pm2 save
pm2 startup 2>/dev/null || true

echo ""
echo -e "${GREEN}============================================${NC}"
echo -e "${GREEN}  ✅ 部署完成！${NC}"
echo -e "${GREEN}============================================${NC}"
echo ""
echo "  前端地址: https://$DOMAIN"
echo "  API 健康: http://localhost:3003/health"
echo "  Swagger:  http://localhost:3003/api/docs (仅内网)"
echo ""
echo "  数据库密码: $DB_PASS"
echo "  JWT 密钥:   $JWT_SECRET"
echo ""
echo "  默认账号: boss / demo"
echo ""
echo "  请保存以上密钥！"
echo -e "${GREEN}============================================${NC}"
